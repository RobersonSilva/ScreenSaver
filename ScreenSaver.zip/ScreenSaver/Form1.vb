﻿Imports System.Net


Public Class Form1

    Dim mouseOffset As Point
    Private Sub Me_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseDown
        mouseOffset = New Point(-e.X, -e.Y)
        Me.Close()
    End Sub
    Private Sub PictureBox1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        Me.Close()
    End Sub
    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click
        Me.Close()
    End Sub
    Private Sub frmmain_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles MyBase.KeyPress
        If e.KeyChar = Microsoft.VisualBasic.ChrW(Keys.R) Then
            MessageBox.Show("Desenvolvido por Roberson Silva" + vbCrLf + "Office Automation")
        ElseIf e.KeyChar = Microsoft.VisualBasic.ChrW(Keys.Space) Then
            Dim font As New Font("Arial", 28, FontStyle.Italic)
            Dim brush As New SolidBrush(Color.FromArgb(64, 192, 255, 255))
            brush.Color = Color.FromArgb(255, 255, 255, 255)
            Dim localIp As IPHostEntry = Dns.GetHostEntry(Dns.GetHostName())
            PictureBox1.CreateGraphics.DrawString("Hostname : " + System.Environment.MachineName + vbCrLf + "Login : " + System.Environment.UserName + vbCrLf + "IP : " + localIp.AddressList(0).ToString, font, brush, 15, 135)
        Else
            Me.Close()
        End If

    End Sub
    Dim images() As String
    Dim RandClass As Random = New Random
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        PictureBox1.Image = Image.FromFile("\\CAMINHO_DA_IMAGEM_NA_REDE\FOTO_PRINCIPAL.JPG")
        images = IO.Directory.GetFiles("\\CAMINHO_DA_IMAGEM_NA_REDE\", "*.jpg")
        PictureBox1.Size = New Point(Me.Width, Me.Height)
        Me.TopMost = True
        Me.Top = 0
        Me.Left = 0
        Me.Size = My.Computer.Screen.WorkingArea.Size
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        Me.WindowState = FormWindowState.Maximized


    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim R As Integer = RandClass.Next(0, images.Count)
        PictureBox1.Image = Image.FromFile(images(R))

    End Sub
End Class